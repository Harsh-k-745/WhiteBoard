// let string = "hi hello hi where are you";
// let cpString=string.replace("hi", "hola");
// console.log(string);
// console.log(cpString);
( A1 + A1 )