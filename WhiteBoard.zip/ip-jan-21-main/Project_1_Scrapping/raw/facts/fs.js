let fs = require("fs");
let path=require("path");
// let content = fs.readFileSync("intro.js");
// console.log(content);
console.log(path.join(__dirname,"abc","def"))