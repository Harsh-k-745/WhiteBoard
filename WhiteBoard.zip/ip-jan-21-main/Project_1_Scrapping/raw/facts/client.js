let ME = require("./lib");
ME.fnprivate();
console.log(ME.pb);
// ME.pb = 13;
ME.fnpublic();